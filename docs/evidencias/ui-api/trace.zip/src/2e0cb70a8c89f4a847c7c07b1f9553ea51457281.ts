import { expect, test } from '@playwright/test';
import { ClienteAutenticacion } from '../../src/api/ClienteAutenticacion';
import { ClienteReservas } from '../../src/api/ClienteReservas';
import { PaginaReserva } from '../../src/pages/PaginaReserva';
import { Reserva, ReservaCreada } from '../../src/types/reserva.types';

test('UI + API - confirmar y consultar la misma reserva', async ({ page, request }) => {
  const token = await new ClienteAutenticacion(request).iniciarSesion();
  const clienteReservas = new ClienteReservas(request, token);
  const paginaReserva = new PaginaReserva(page);
  const roomid = 1;
  const huesped = {
    firstname: 'Catalina',
    lastname: 'Osorio',
    email: 'reserva@example.com',
    phone: '12345678910'
  };

  const respuestaDisponibilidad = await clienteReservas.consultarReservas(roomid);
  expect(respuestaDisponibilidad.status(), 'Consulta de disponibilidad').toBe(200);
  const { bookings }: { bookings: ReservaCreada[] } = await respuestaDisponibilidad.json();

  const hoy = new Date();
  const rangos = Array.from({ length: 30 }, (_, indice) => {
    const entrada = new Date(hoy);
    entrada.setUTCDate(entrada.getUTCDate() + 90 + indice * 3);
    const salida = new Date(entrada);
    salida.setUTCDate(salida.getUTCDate() + 2);
    return {
      checkin: entrada.toISOString().slice(0, 10),
      checkout: salida.toISOString().slice(0, 10)
    };
  });
  const bookingdates = rangos.find(({ checkin, checkout }) =>
    bookings.every(({ bookingdates }) =>
      checkout <= bookingdates.checkin || checkin >= bookingdates.checkout
    )
  );
  if (!bookingdates) throw new Error(`No hay fechas disponibles para la habitación ${roomid}`);

  const reserva: Reserva = { roomid, ...huesped, depositpaid: false, bookingdates };

  await paginaReserva.abrirFormulario(reserva);
  const creacion = await paginaReserva.enviarReserva(huesped);
  expect(creacion.status(), 'Creación de la reserva desde el formulario').toBe(201);
  expect(creacion.request().postDataJSON()).toMatchObject({ ...reserva });
  const { bookingid }: ReservaCreada = await creacion.json();
  expect(Number.isInteger(bookingid)).toBe(true);
  expect(bookingid).toBeGreaterThan(0);

  await expect(paginaReserva.confirmacion()).toBeVisible();
  await expect(paginaReserva.fechasConfirmadas(bookingdates.checkin, bookingdates.checkout)).toBeVisible();

  const consulta = await clienteReservas.consultarReserva(bookingid);
  expect(consulta.status(), `Consulta de la reserva ${bookingid} creada por la UI`).toBe(200);
  expect(await consulta.json()).toMatchObject({
    bookingid,
    roomid,
    bookingdates,
    firstname: huesped.firstname,
    lastname: huesped.lastname
  });
});
